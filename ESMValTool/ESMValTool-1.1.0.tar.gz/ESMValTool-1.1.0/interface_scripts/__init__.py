"""
init for interface scripts
"""
