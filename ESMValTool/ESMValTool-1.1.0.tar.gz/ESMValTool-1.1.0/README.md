# ESMValTool
 [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/ESMValGroup?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

ESMValTool: A community diagnostic and performance metrics tool for routine evaluation of Earth system models in CMIP 
