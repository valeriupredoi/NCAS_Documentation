This is the pep8-checker with an updated 'tokenize'-module to use ';' as
a comment (NCL-syntax) instead of '#' (Pyhton-syntax). See the
'../pep8-checker/README.rst' for more details. 
