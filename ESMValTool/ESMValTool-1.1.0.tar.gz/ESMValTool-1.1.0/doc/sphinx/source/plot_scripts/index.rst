NCL plotting scripts library
==============================

Contents:

.. toctree::
   :maxdepth: 2

   aux_plotting
   contour_maps
   legends
   monsoon_domain_panels
   monsoon_panels
   portrait_plot
   scatterplot
   taylor_plot
   xy_line
   zonalmean_profile
