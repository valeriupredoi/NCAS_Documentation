:mod:`monsoon_domain_panels`
============================
.. function::  plot_precip_domain(cols[*]:integer, rows[*]:float, curr_idx[1]:integer, curr_page[1]:integer, res[1]:logical, storage_name[1]:string, storage_vault[1]:logical, wks[1]:graphic, di[1]:logical, plot_settings[1]:logical, valid_statistics[*]:string, debuginfo[1]:logical, figures_per_page[*]:integer, model_panel_placement[*]:integer, figure_panel_placement[*]:integer, plot_array[*]:graphic, type_specifier[1]:string, no_figures_on_this_page[1]:integer)
.. function::  precip_domain(storage_vault [1] : logical, di [1] : logical, plot_settings [1] : logical, storage_name [1] : string, debuginfo [1] : logical, valid_statistics [*] : string, res [1] : logical)
